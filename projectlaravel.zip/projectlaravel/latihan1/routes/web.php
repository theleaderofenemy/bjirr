<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('home', [
        "title" => "Home",
        "name" => "Siddiq",
        "email" => "siddiq@gmail.com",
        "image" => "2.jpg"
    ]);
    
});

Route::get('/about', function () {
    return view('about',[
        "title" => "About"
    ]);
});

    Route::get('/posts', function () {
        $blog_posts = [[
            "title" => "Judul Post Pertama",
            "slug" => "judul-post-pertama",
            "author" => "Siddiq AJA",
            "body" => "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Magnam ipsum esse, maxime quos eos tenetur rerum fugiat voluptas illo laborum eum iure, odio labore a quaerat earum voluptatem fuga et? Vitae obcaecati dolor consectetur, possimus aliquid, quod vel optio animi aperiam, quae qui sapiente non corrupti veritatis mollitia voluptate doloribus facilis voluptatum iusto nihil quisquam dolores minima. Deserunt ullam magni eligendi nam amet tenetur atque quibusdam cum commodi nobis, qui nisi. Harum incidunt distinctio, nesciunt ipsum sequi accusantium aliquid esse."
        ],
        [
            "title" => "Judul Post Kedua",
            "slug" => "judul-post-Kedua",
            "author" => "Siddiq AJA",
            "body" => "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Minima repellendus nobis, ipsum nesciunt sapiente iste illo earum ut. Minus in non, neque totam perspiciatis hic facilis porro, perferendis voluptatem iusto necessitatibus quidem impedit error magni qui! Officiis rerum quia quo fuga voluptate eius tenetur accusamus natus illum similique ratione iste libero, blanditiis maxime earum eligendi obcaecati culpa, odio non! Blanditiis ipsa totam voluptas a odit dolorum molestiae ab, placeat molestias nihil, hic sit iusto. Facilis sint deleniti consectetur eos quia doloribus, voluptas soluta dolor saepe et, unde atque iure deserunt vel quidem! Numquam expedita, minus laudantium quod nobis facere. In."
        ],
        ];
    return view('posts',[
        "title" => "Posts",
        "posts" => $blog_posts
    ]);
});


//halaman sigle masih ada kesalahan disini
Route::get('posts/{slug}', function($slug){
    return view('post',[
        "title" => "Single Post"
    ]);
});