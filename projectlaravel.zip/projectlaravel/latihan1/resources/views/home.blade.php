     @extends('layouts.main')
     @section('container')
     <script src="js/script.js"></script>
     <h3 class="btn-shine">Selamat Datang Di web</h3>
      <h1>Halaman Home</h1>
      <h3>{{ $name }}</h3>
      <h2>{{ $email }}</h2>
      <img src="img/{{ $image }}" alt="{{ $name }}" width="200px">
      @endsection