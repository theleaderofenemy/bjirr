
@extends('layouts.main')
@section('container')
<article>
    <h2>Judul</h2>
    <h5>Author</h5>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nisi est molestias magnam. Ea dolorum animi voluptas. Reprehenderit animi cupiditate nobis a maiores. Non aspernatur sit ullam autem alias, doloremque sunt?</p>
<article>

    <a href="/posts">back to Posts</a>
 @endsection