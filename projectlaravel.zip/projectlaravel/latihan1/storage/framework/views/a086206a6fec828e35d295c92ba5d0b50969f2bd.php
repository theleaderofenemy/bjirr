
<?php $__env->startSection('container'); ?>

<?php if(count($posts) > 0): ?>
<div class="card mb-3">
    <img src="..." class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">Card title</h5>
      <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
      <p class="card-text"><small class="text-body-secondary">Last updated 3 mins ago</small></p>
    </div>
</div>
<?php else: ?>
<p class="text-center fs-4">No post found.</p>
<?php endif; ?>



<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<article class="mb-5">
 <h2>
    <a href="/posts/<?php echo e($post["slug"]); ?>"><?php echo e($post["title"]); ?></a>
</h2>
 <h5>By: <?php echo e($post["author"]); ?></h5>
 <p><?php echo e($post["body"]); ?></p>
</article>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projectlaravel\latihan1\resources\views/posts.blade.php ENDPATH**/ ?>