     
     <?php $__env->startSection('container'); ?>
     <script src="js/script.js"></script>
     <h3 class="btn-shine">Selamat Datang Di web</h3>
      <h1>Halaman Home</h1>
      <h3><?php echo e($name); ?></h3>
      <h2><?php echo e($email); ?></h2>
      <img src="img/<?php echo e($image); ?>" alt="<?php echo e($name); ?>" width="200px">
      <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projectlaravel\latihan1\resources\views/home.blade.php ENDPATH**/ ?>