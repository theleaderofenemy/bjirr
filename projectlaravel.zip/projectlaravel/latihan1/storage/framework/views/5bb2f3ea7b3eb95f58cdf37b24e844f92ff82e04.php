

<?php $__env->startSection('container'); ?>
<article>
    <h2>Judul</h2>
    <h5>Author</h5>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nisi est molestias magnam. Ea dolorum animi voluptas. Reprehenderit animi cupiditate nobis a maiores. Non aspernatur sit ullam autem alias, doloremque sunt?</p>
<article>

    <a href="/posts">back to Posts</a>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projectlaravel\latihan1\resources\views/post.blade.php ENDPATH**/ ?>